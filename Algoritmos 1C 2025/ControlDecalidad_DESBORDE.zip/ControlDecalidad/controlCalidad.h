#ifndef CONTROLCALIDAD_H_INCLUDED
#define CONTROLCALIDAD_H_INCLUDED

#include "headerCola.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define REALIZADO 0
#define TAM_CHAR 10
#define TAM_LINEA 100

typedef struct
{
    char codLote[TAM_CHAR];
    char idProd [TAM_CHAR];
    char resulControl[TAM_CHAR];
} tLote;

void parsearLinea(tLote *reg, char *linea);
int cargarArchivoPrueba(char *nombArchivo);
int bajarArchivo(char *archivo, tCola *cola);
int cargarArchivo(char *archivo, tCola *cola);
int procesarEntrada(tCola *cola);
void mostrarArchivoEntrada(tCola *cola);
void mostrarArchivo(const char *nombreArchivo, const char *titulo);
void mostrarArchSalida(const char * nombArchAprob, const char * nombArchObs);

#endif // CONTROLCALIDAD_H_INCLUDED
