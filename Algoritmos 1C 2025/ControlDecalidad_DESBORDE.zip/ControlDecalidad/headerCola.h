#ifndef HEADERCOLA_H_INCLUDED
#define HEADERCOLA_H_INCLUDED


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define TAM_COLA 1000
#define MINIMO(x,y) ((x)<(y)? (x):(y));
#define COLA_LLENA 1
#define COLA_VACIA 1
#define COLA_NO_VACIA 0
#define COLA_DISPONIBLE 0

typedef struct{
char cola[TAM_COLA];
unsigned pri;
unsigned ult;
unsigned tam_disp;

}tCola;

void crearCola(tCola *cola);
int ponerEnCola(tCola *cola,const void* dato,unsigned tam);
int sacarDeCola(tCola *cola,void* dato,unsigned tam);
int verPrimero (const tCola *cola,void* dato,unsigned tam);
void vaciarCola(tCola *cola);
int colaVacia(const tCola *cola);
int colaLlena(const tCola *cola, unsigned tam);

#endif // HEADERCOLA_H_INCLUDED
