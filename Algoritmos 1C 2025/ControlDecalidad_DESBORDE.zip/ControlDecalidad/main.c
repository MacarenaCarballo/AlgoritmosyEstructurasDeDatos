#include "controlCalidad.h"


int existeArchivo(const char *nombreArchivo)
{
    FILE *archivo = fopen(nombreArchivo, "r");
    if (archivo)
    {
        fclose(archivo);
        return 1;  // Existe
    }
    return 0;  // No existe
}

int main()
{
    //cargarArchivoPrueba("entrada.txt");
    tCola cola,
        colaAux;

    crearCola(&cola);
    crearCola(&colaAux);

    bajarArchivo("entrada.txt", &cola);
    char option;

    do
    {
        puts("\t \t MENU \n"
             "a) Procesar archivo de entrada: \n"
             "b) Mostrar archivo de entrada: \n"
             "c) Mostrar Archivo de salida \n"
             "f) Salir \n\n"
             "Elija su opcion: ");

        scanf(" %c", &option);
        option=tolower(option);
        fflush(stdin);

        switch(option)
        {

        case 'a':
        {
                    colaAux=cola;
                    procesarEntrada(&cola);
                    puts("\nArchivo Procesado!\n");
            break;
        }
        case 'b':
        {
            colaAux=cola;
            mostrarArchivoEntrada(&colaAux);
            puts("\nSe mostro el archivo de entrada\n");
            break;
        }

        case 'c':
            mostrarArchSalida("lotesAprobados.txt","lotesObservados.txt");
            break;

        case 'f':
            puts("\nSaliendo");
            break;
        default:
            printf("\nOpcion invalida. Intente de nuevo.\n");


    }

     system("pause");
        system("cls");

    }while(option != 'f');

    vaciarCola(&cola);
    vaciarCola(&colaAux);


    return 0;
}


