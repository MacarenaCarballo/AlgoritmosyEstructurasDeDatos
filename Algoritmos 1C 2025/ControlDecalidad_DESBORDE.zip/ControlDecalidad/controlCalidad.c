#include "controlCalidad.h"

int cargarArchivoPrueba(char *nombArchivo)
{
    size_t i;
    FILE *pf=fopen(nombArchivo,"wt");

    if(!pf)
        return -1;

    tLote lotes[]= {{"L001", "1001", "OK"},
        {"L001", "1002", "FALLA"},
        {"L001", "1003", "OK"},
        {"L002", "2001", "FALLA"},
        {"L002", "2002", "FALLA"},
        {"L002", "2003", "OK"},
        {"L003", "3001", "OK"},
        {"L003", "3002", "OK"},
        {"L003", "3003", "FALLA"},
        {"L003", "3004", "OK"}
    };
    size_t n=(int)(sizeof(lotes)/sizeof(tLote));
    tLote *vec = lotes;

    for(i=0; i<n; i++){
        fprintf(pf,"%s,%s,%s\n",vec->codLote,vec->idProd,vec->resulControl);
        vec++;  }

    fclose(pf);
    return 0;
}

void parsearLinea(tLote *reg, char *linea) {
        char *act = strchr(linea, '\n');
        if (act)
            *act = '\0';
        act=strrchr(linea,',');
        strcpy(reg->resulControl,act+1);

        *act='\0';
        act=strrchr(linea,',');
        strcpy(reg->idProd,act+1);

        *act='\0';
        strcpy(reg->codLote,linea);
}

int bajarArchivo(char *archivo, tCola *cola)
{
    char linea[100];
    tLote registro;
    FILE *pf=fopen(archivo,"rt");
    if(!pf)
    {
        printf("No se pudo abrir el archivo\n");
        return -1;
    }

    while(fgets(linea, sizeof(linea), pf)){
        parsearLinea(&registro,linea);
        ponerEnCola(cola,&registro,sizeof(tLote));
    }

    fclose(pf);
    return 0;
}

int procesarEntrada(tCola *cola)
{
    tCola colaAux;
    tLote reg1;
    int flag=0;
    char lote[10];

    crearCola(&colaAux);
    sacarDeCola(cola,&reg1,sizeof(tLote));
    strcpy(lote,reg1.codLote);

    do
    {
        if(strcmpi(lote,reg1.codLote)==0)
        {
            if(strcmpi(reg1.resulControl,"FALLA")==0)
                flag=1;
            ponerEnCola(&colaAux,&reg1,sizeof(tLote));
            sacarDeCola(cola,&reg1,sizeof(tLote));
        }
        else
        {
            if(flag==1)
            {
                cargarArchivo("lotesObservados.txt",&colaAux);
                vaciarCola(&colaAux);
            }
            else
            {
                cargarArchivo("lotesAprobados.txt",&colaAux);
                vaciarCola(&colaAux);
            }
            ponerEnCola(&colaAux,&reg1,sizeof(tLote));
            strcpy(lote,reg1.codLote);
            flag=0;
        }
    }
    while(!colaVacia(cola));


    if(flag == 1)
        cargarArchivo("lotesObservados.txt", &colaAux);
    else
        cargarArchivo("lotesAprobados.txt", &colaAux);


    vaciarCola(&colaAux);

    return 0;
}

int cargarArchivo(char *archivo, tCola *cola)
{
    tLote reg;
    FILE *pa=fopen(archivo,"at");
    if(!pa)
        return -1;
    while(!colaVacia(cola))
    {
        sacarDeCola(cola,&reg,sizeof(tLote));
        fprintf(pa,"%s,%s,%s\n",reg.codLote,reg.idProd,reg.resulControl);
    }
    fclose(pa);
    return 0;
}

void mostrarArchivoEntrada(tCola *cola)
{
    tLote registro;

    while(colaVacia(cola)== COLA_NO_VACIA)
    {
        sacarDeCola(cola,&registro,sizeof(tLote));
        printf("%s, %s, %s\n", registro.codLote, registro.idProd, registro.resulControl);
    }
}

void mostrarArchivo(const char *nombreArchivo, const char *titulo) {
    FILE *archivo = fopen(nombreArchivo, "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo: %s\n", nombreArchivo);
        return;
    }

    printf("\n=== %s ===\n", titulo);
    printf("C�d.Lote\tID Producto\tResultado\n");
    printf("--------------------------------\n");

    char linea[TAM_LINEA];
    tLote lote;

    while (fgets(linea, sizeof(linea), archivo) != NULL) {
        parsearLinea(&lote, linea);

        // Mostrar la informaci�n formateada
        printf("%-10s\t%-12s\t%-10s\n",
               lote.codLote, lote.idProd, lote.resulControl);
    }

    fclose(archivo);
    printf("--------------------------------\n");
}

void mostrarArchSalida(const char *nombArchAprob, const char *nombArchObs) {
    // Mostrar archivo de aprobados
    mostrarArchivo(nombArchAprob, "LOTES APROBADOS");

    // Mostrar archivo de observados
    mostrarArchivo(nombArchObs, "LOTES OBSERVADOS");
}

